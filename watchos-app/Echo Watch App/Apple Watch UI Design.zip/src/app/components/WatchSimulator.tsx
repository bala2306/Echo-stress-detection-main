import { useState, useEffect } from "react";

type Screen =
  | "watchface"
  | "home"
  | "vitals"
  | "risk"
  | "alert"
  | "emergency";

const screens: Screen[] = ["watchface", "home", "vitals", "risk", "alert", "emergency"];

const screenLabels: Record<Screen, string> = {
  watchface: "Watch Face",
  home: "Home",
  vitals: "Live Vitals",
  risk: "Risk Level",
  alert: "Stroke Alert",
  emergency: "Emergency",
};

function useAnimatedValue(target: number, delay = 0) {
  const [value, setValue] = useState(target - 5);
  useEffect(() => {
    const t = setTimeout(() => setValue(target), delay);
    return () => clearTimeout(t);
  }, [target, delay]);
  return value;
}

// ─── Watch Face ───────────────────────────────────────────────────────────────
function WatchFaceScreen() {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setTick((t) => t + 1), 1000);
    return () => clearInterval(id);
  }, []);

  const now = new Date();
  const hours = now.getHours().toString().padStart(2, "0");
  const minutes = now.getMinutes().toString().padStart(2, "0");
  const day = now.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });

  return (
    <div className="flex flex-col items-center justify-between h-full px-2 py-3">
      {/* Time */}
      <div className="flex flex-col items-center mt-1">
        <span className="text-white text-[11px] tracking-widest opacity-70">{day.toUpperCase()}</span>
        <span className="text-white font-thin mt-0.5" style={{ fontSize: 46, letterSpacing: -1 }}>
          {hours}:{minutes}
        </span>
      </div>

      {/* Echo Complication */}
      <div className="w-full rounded-xl px-3 py-2" style={{ background: "rgba(48,209,88,0.15)", border: "1px solid rgba(48,209,88,0.4)" }}>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
          <span className="text-green-400 text-[11px] tracking-wide">ECHO MONITORING</span>
        </div>
        <div className="flex justify-between mt-1">
          <div className="flex flex-col items-center">
            <span className="text-white text-[13px]">72</span>
            <span className="text-gray-500 text-[9px]">BPM</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-white text-[13px]">38ms</span>
            <span className="text-gray-500 text-[9px]">HRV</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-green-400 text-[13px]">LOW</span>
            <span className="text-gray-500 text-[9px]">RISK</span>
          </div>
        </div>
      </div>

      {/* Bottom complications row */}
      <div className="flex gap-2 w-full">
        <div className="flex-1 rounded-lg py-1.5 flex flex-col items-center" style={{ background: "rgba(255,255,255,0.08)" }}>
          <span className="text-blue-400 text-[13px]">36.6°</span>
          <span className="text-gray-500 text-[9px]">TEMP</span>
        </div>
        <div className="flex-1 rounded-lg py-1.5 flex flex-col items-center" style={{ background: "rgba(255,255,255,0.08)" }}>
          <span className="text-orange-400 text-[13px]">0.4μS</span>
          <span className="text-gray-500 text-[9px]">EDA</span>
        </div>
      </div>
    </div>
  );
}

// ─── Home Screen ──────────────────────────────────────────────────────────────
function HomeScreen({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  return (
    <div className="flex flex-col items-center justify-between h-full px-3 py-3">
      {/* Logo + status */}
      <div className="flex flex-col items-center gap-1 mt-1">
        <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: "rgba(10,132,255,0.2)", border: "2px solid rgba(10,132,255,0.6)" }}>
          <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5">
            <path d="M12 2C8 2 4 6 4 11c0 3 1.5 5.5 4 7l4 4 4-4c2.5-1.5 4-4 4-7 0-5-4-9-8-9z" fill="rgba(10,132,255,0.8)" />
            <path d="M9 11l2 2 4-4" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        <span className="text-white text-[15px]" style={{ letterSpacing: -0.3 }}>Echo</span>
        <div className="flex items-center gap-1.5">
          <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
          <span className="text-green-400 text-[11px]">Monitoring Active</span>
        </div>
      </div>

      {/* Quick stats */}
      <div className="w-full space-y-1.5">
        <button onClick={() => onNavigate("vitals")} className="w-full rounded-xl px-3 py-2 flex justify-between items-center active:opacity-70" style={{ background: "rgba(255,255,255,0.08)" }}>
          <span className="text-gray-400 text-[12px]">Live Vitals</span>
          <div className="flex items-center gap-1.5">
            <span className="text-white text-[12px]">72 BPM</span>
            <span className="text-gray-600 text-[11px]">›</span>
          </div>
        </button>
        <button onClick={() => onNavigate("risk")} className="w-full rounded-xl px-3 py-2 flex justify-between items-center active:opacity-70" style={{ background: "rgba(255,255,255,0.08)" }}>
          <span className="text-gray-400 text-[12px]">Stroke Risk</span>
          <div className="flex items-center gap-1.5">
            <span className="text-green-400 text-[12px]">3.2%</span>
            <span className="text-gray-600 text-[11px]">›</span>
          </div>
        </button>
      </div>

      <span className="text-gray-600 text-[9px] text-center">Last analyzed 12s ago</span>
    </div>
  );
}

// ─── Vitals Screen ────────────────────────────────────────────────────────────
function VitalsScreen() {
  const [frame, setFrame] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setFrame((f) => f + 1), 800);
    return () => clearInterval(id);
  }, []);

  // Simulate a live PPG-like waveform
  const wavePoints = Array.from({ length: 20 }, (_, i) => {
    const x = (i / 19) * 148;
    const base = 18;
    const cycle = (i + frame) % 10;
    const y = cycle < 3 ? base - cycle * 6 : cycle < 5 ? base - (10 - cycle) * 9 : base + Math.sin(cycle) * 2;
    return `${x},${Math.max(2, Math.min(34, y))}`;
  }).join(" ");

  return (
    <div className="flex flex-col h-full px-3 py-2 gap-2">
      <span className="text-white text-[13px] text-center">Live Vitals</span>

      {/* PPG Wave */}
      <div className="rounded-xl px-2 py-1.5" style={{ background: "rgba(255,255,255,0.06)" }}>
        <div className="flex justify-between items-center mb-1">
          <span className="text-gray-500 text-[9px]">PPG SIGNAL</span>
          <span className="text-green-400 text-[9px]">● LIVE</span>
        </div>
        <svg viewBox="0 0 148 36" className="w-full" style={{ height: 28 }}>
          <polyline points={wavePoints} fill="none" stroke="#30D158" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </div>

      {/* Metric grid */}
      <div className="grid grid-cols-2 gap-1.5">
        {[
          { label: "HEART RATE", value: "72", unit: "BPM", color: "text-red-400" },
          { label: "HRV", value: "38", unit: "ms", color: "text-blue-400" },
          { label: "SKIN TEMP", value: "36.6", unit: "°C", color: "text-orange-400" },
          { label: "EDA", value: "0.4", unit: "μS", color: "text-purple-400" },
        ].map((m) => (
          <div key={m.label} className="rounded-xl p-2 flex flex-col" style={{ background: "rgba(255,255,255,0.07)" }}>
            <span className="text-gray-500 text-[8px] tracking-wide">{m.label}</span>
            <div className="flex items-baseline gap-0.5 mt-0.5">
              <span className={`${m.color} text-[16px]`}>{m.value}</span>
              <span className="text-gray-500 text-[9px]">{m.unit}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Risk Screen ──────────────────────────────────────────────────────────────
function RiskScreen() {
  const risk = 3.2;
  const circumference = 2 * Math.PI * 42;
  const offset = circumference - (risk / 100) * circumference;

  return (
    <div className="flex flex-col items-center justify-between h-full px-3 py-3">
      <span className="text-white text-[13px]">Stroke Risk</span>

      {/* Circular gauge */}
      <div className="relative flex items-center justify-center">
        <svg viewBox="0 0 100 100" className="w-24 h-24">
          <circle cx="50" cy="50" r="42" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="6" />
          <circle
            cx="50" cy="50" r="42" fill="none"
            stroke="#30D158" strokeWidth="6"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
            transform="rotate(-90 50 50)"
            style={{ transition: "stroke-dashoffset 1s ease" }}
          />
        </svg>
        <div className="absolute flex flex-col items-center">
          <span className="text-green-400" style={{ fontSize: 22 }}>{risk}%</span>
          <span className="text-gray-500 text-[9px]">RISK</span>
        </div>
      </div>

      {/* Status label */}
      <div className="rounded-xl px-3 py-1.5 flex items-center gap-2" style={{ background: "rgba(48,209,88,0.15)", border: "1px solid rgba(48,209,88,0.3)" }}>
        <div className="w-2 h-2 rounded-full bg-green-400" />
        <span className="text-green-400 text-[12px]">LOW RISK</span>
      </div>

      {/* Model info */}
      <div className="w-full rounded-xl px-3 py-1.5" style={{ background: "rgba(255,255,255,0.06)" }}>
        <div className="flex justify-between">
          <span className="text-gray-500 text-[10px]">Model confidence</span>
          <span className="text-white text-[10px]">94%</span>
        </div>
        <div className="flex justify-between mt-0.5">
          <span className="text-gray-500 text-[10px]">Last window</span>
          <span className="text-white text-[10px]">30s</span>
        </div>
      </div>
    </div>
  );
}

// ─── Alert Screen ─────────────────────────────────────────────────────────────
function AlertScreen({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  const [flash, setFlash] = useState(false);
  useEffect(() => {
    const id = setInterval(() => setFlash((f) => !f), 600);
    return () => clearInterval(id);
  }, []);

  return (
    <div
      className="flex flex-col items-center justify-between h-full px-3 py-3"
      style={{ background: flash ? "rgba(255,69,58,0.12)" : "rgba(255,69,58,0.04)", transition: "background 0.3s" }}
    >
      {/* Alert icon */}
      <div className={`w-12 h-12 rounded-full flex items-center justify-center mt-1 ${flash ? "scale-105" : "scale-100"}`}
        style={{ background: "rgba(255,69,58,0.25)", border: "2px solid rgba(255,69,58,0.8)", transition: "transform 0.3s" }}>
        <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
          <path d="M12 2L2 20h20L12 2z" fill="rgba(255,69,58,0.3)" stroke="#FF453A" strokeWidth="1.5" strokeLinejoin="round" />
          <path d="M12 9v5M12 16.5v.5" stroke="#FF453A" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      </div>

      {/* Message */}
      <div className="flex flex-col items-center gap-1 text-center">
        <span className="text-red-400 text-[14px]" style={{ letterSpacing: -0.3 }}>Stroke Detected</span>
        <span className="text-gray-400 text-[10px] leading-tight px-1">Physiological signature identified. Seek emergency care now.</span>
        <div className="mt-1 px-2 py-0.5 rounded-full" style={{ background: "rgba(255,69,58,0.2)" }}>
          <span className="text-red-400 text-[10px]">Risk Score: 87.4%</span>
        </div>
      </div>

      {/* CTA */}
      <button
        onClick={() => onNavigate("emergency")}
        className="w-full rounded-2xl py-3 flex items-center justify-center gap-2 active:opacity-80"
        style={{ background: "#FF453A" }}
      >
        <svg viewBox="0 0 24 24" fill="none" className="w-4 h-4">
          <path d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1-9.4 0-17-7.6-17-17 0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1L6.6 10.8z" fill="white" />
        </svg>
        <span className="text-white text-[13px]">Call 911</span>
      </button>
    </div>
  );
}

// ─── Emergency Screen ─────────────────────────────────────────────────────────
function EmergencyScreen() {
  const [calling, setCalling] = useState(false);
  const [notified, setNotified] = useState(false);

  return (
    <div className="flex flex-col items-center justify-between h-full px-3 py-3">
      <span className="text-red-400 text-[13px]">Emergency</span>

      {/* Location chip */}
      <div className="w-full rounded-xl px-3 py-2" style={{ background: "rgba(255,255,255,0.07)" }}>
        <div className="flex items-center gap-2">
          <svg viewBox="0 0 24 24" fill="none" className="w-3.5 h-3.5 flex-shrink-0">
            <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5S10.62 6.5 12 6.5s2.5 1.12 2.5 2.5S13.38 11.5 12 11.5z" fill="#0A84FF" />
          </svg>
          <div>
            <span className="text-white text-[11px]">Location shared</span>
            <p className="text-gray-500 text-[9px]">37.334°N, 122.009°W</p>
          </div>
        </div>
      </div>

      {/* Action buttons */}
      <div className="w-full space-y-2">
        <button
          onClick={() => setCalling(true)}
          className="w-full rounded-2xl py-2.5 flex items-center justify-center gap-2 active:opacity-80"
          style={{ background: calling ? "#1C1C1E" : "#FF453A", border: calling ? "1px solid #FF453A" : "none" }}
        >
          {calling ? (
            <>
              <div className="w-2 h-2 rounded-full bg-red-400 animate-pulse" />
              <span className="text-red-400 text-[12px]">Calling 911...</span>
            </>
          ) : (
            <span className="text-white text-[12px]">Call 911</span>
          )}
        </button>

        <button
          onClick={() => setNotified(true)}
          className="w-full rounded-2xl py-2.5 flex items-center justify-center gap-2 active:opacity-80"
          style={{ background: notified ? "rgba(48,209,88,0.15)" : "rgba(255,255,255,0.1)", border: notified ? "1px solid rgba(48,209,88,0.5)" : "none" }}
        >
          {notified ? (
            <span className="text-green-400 text-[12px]">✓ Contacts Notified</span>
          ) : (
            <span className="text-white text-[12px]">Notify Contacts</span>
          )}
        </button>
      </div>

      <span className="text-gray-600 text-[9px] text-center">Alert sent • {new Date().toLocaleTimeString()}</span>
    </div>
  );
}

// ─── Watch Case + Crown ───────────────────────────────────────────────────────
function WatchCase({ children, screen }: { children: React.ReactNode; screen: Screen }) {
  const isAlert = screen === "alert" || screen === "emergency";

  return (
    <div className="relative" style={{ width: 200, height: 240 }}>
      {/* Watch body */}
      <div
        className="absolute inset-0 rounded-[44px]"
        style={{
          background: "linear-gradient(145deg, #3a3a3c, #1c1c1e)",
          boxShadow: isAlert
            ? "0 0 0 2px #3a3a3c, 0 0 40px rgba(255,69,58,0.4), 0 20px 60px rgba(0,0,0,0.8)"
            : "0 0 0 2px #3a3a3c, 0 20px 60px rgba(0,0,0,0.8)",
          transition: "box-shadow 0.4s ease",
        }}
      />

      {/* Digital Crown */}
      <div
        className="absolute rounded-r-lg"
        style={{ right: -8, top: 64, width: 10, height: 32, background: "linear-gradient(180deg, #4a4a4c, #2c2c2e)", boxShadow: "2px 0 4px rgba(0,0,0,0.5)" }}
      />
      {/* Side button */}
      <div
        className="absolute rounded-r-lg"
        style={{ right: -8, top: 104, width: 10, height: 16, background: "linear-gradient(180deg, #4a4a4c, #2c2c2e)", boxShadow: "2px 0 4px rgba(0,0,0,0.5)" }}
      />

      {/* Screen bezel */}
      <div
        className="absolute"
        style={{
          inset: 6,
          borderRadius: 38,
          background: "#000",
          overflow: "hidden",
          boxShadow: "inset 0 0 0 1px rgba(255,255,255,0.05)",
        }}
      >
        {children}
      </div>

      {/* Screen glare */}
      <div
        className="absolute pointer-events-none"
        style={{
          inset: 6,
          borderRadius: 38,
          background: "linear-gradient(135deg, rgba(255,255,255,0.06) 0%, transparent 50%)",
        }}
      />
    </div>
  );
}

// ─── Screen Selector Tabs ─────────────────────────────────────────────────────
function ScreenTabs({ current, onChange }: { current: Screen; onChange: (s: Screen) => void }) {
  return (
    <div className="flex flex-wrap gap-2 justify-center max-w-lg">
      {screens.map((s) => (
        <button
          key={s}
          onClick={() => onChange(s)}
          className="px-3 py-1.5 rounded-full text-[12px] transition-all active:scale-95"
          style={{
            background: current === s
              ? s === "alert" || s === "emergency" ? "rgba(255,69,58,0.25)" : "rgba(10,132,255,0.25)"
              : "rgba(255,255,255,0.07)",
            border: current === s
              ? s === "alert" || s === "emergency" ? "1px solid rgba(255,69,58,0.6)" : "1px solid rgba(10,132,255,0.6)"
              : "1px solid rgba(255,255,255,0.1)",
            color: current === s
              ? s === "alert" || s === "emergency" ? "#FF453A" : "#0A84FF"
              : "#8E8E93",
          }}
        >
          {screenLabels[s]}
        </button>
      ))}
    </div>
  );
}

// ─── Info Panel ───────────────────────────────────────────────────────────────
const screenInfo: Record<Screen, { count: string; desc: string }> = {
  watchface: { count: "Screen 1 / 6", desc: "Always-on watch face with Echo complication — shows HR, HRV, and current risk at a glance without opening the app." },
  home: { count: "Screen 2 / 6", desc: "App home screen — displays monitoring status, quick vitals summary, and entry points to detailed views." },
  vitals: { count: "Screen 3 / 6", desc: "Live vitals screen — real-time PPG waveform, heart rate, HRV, skin temperature, and electrodermal activity (EDA)." },
  risk: { count: "Screen 4 / 6", desc: "Stroke risk output — shows the PatchTST model's current probability estimate with confidence and last-window timestamp." },
  alert: { count: "Screen 5 / 6", desc: "Emergency alert — haptic + visual pulse when risk exceeds threshold. Shows risk score and one-tap 911 call." },
  emergency: { count: "Screen 6 / 6", desc: "Emergency actions — active 911 call state, one-tap contact notification, and GPS location confirmation." },
};

// ─── Main Simulator ───────────────────────────────────────────────────────────
export function WatchSimulator() {
  const [screen, setScreen] = useState<Screen>("watchface");

  function navigate(s: Screen) {
    setScreen(s);
  }

  function renderScreen() {
    switch (screen) {
      case "watchface": return <WatchFaceScreen />;
      case "home": return <HomeScreen onNavigate={navigate} />;
      case "vitals": return <VitalsScreen />;
      case "risk": return <RiskScreen />;
      case "alert": return <AlertScreen onNavigate={navigate} />;
      case "emergency": return <EmergencyScreen />;
    }
  }

  const info = screenInfo[screen];
  const isAlert = screen === "alert" || screen === "emergency";

  return (
    <div className="flex flex-col items-center gap-10 w-full">
      {/* Header */}
      <div className="text-center">
        <div className="flex items-center justify-center gap-2 mb-1">
          <div className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
          <span className="text-blue-400 text-[13px] tracking-widest uppercase">Echo · watchOS</span>
        </div>
        <h1 className="text-white" style={{ fontSize: 28, letterSpacing: -0.5 }}>Stroke Detection App</h1>
        <p className="text-gray-500 text-[13px] mt-1">Apple Watch UI Prototype · 6 Screens Required</p>
      </div>

      {/* Watch */}
      <WatchCase screen={screen}>
        {renderScreen()}
      </WatchCase>

      {/* Info card */}
      <div
        className="rounded-2xl px-5 py-4 max-w-xs w-full"
        style={{
          background: isAlert ? "rgba(255,69,58,0.08)" : "rgba(255,255,255,0.05)",
          border: isAlert ? "1px solid rgba(255,69,58,0.2)" : "1px solid rgba(255,255,255,0.1)",
        }}
      >
        <div className="flex justify-between items-start mb-1">
          <span className="text-gray-400 text-[11px] tracking-wide">{info.count}</span>
          <span className={`text-[11px] px-2 py-0.5 rounded-full ${isAlert ? "text-red-400 bg-red-400/10" : "text-blue-400 bg-blue-400/10"}`}>
            {screenLabels[screen]}
          </span>
        </div>
        <p className="text-gray-300 text-[12px] leading-relaxed">{info.desc}</p>
      </div>

      {/* Screen tabs */}
      <div className="flex flex-col items-center gap-3">
        <span className="text-gray-600 text-[11px] uppercase tracking-widest">Navigate Screens</span>
        <ScreenTabs current={screen} onChange={setScreen} />
      </div>

      {/* Summary table */}
      <div className="w-full max-w-lg rounded-2xl overflow-hidden" style={{ border: "1px solid rgba(255,255,255,0.1)" }}>
        <div className="px-5 py-3" style={{ background: "rgba(255,255,255,0.05)" }}>
          <span className="text-white text-[13px]">UI Screen Inventory</span>
        </div>
        <div className="divide-y" style={{ borderColor: "rgba(255,255,255,0.06)" }}>
          {[
            { screen: "Watch Face Complication", priority: "Always-On", color: "text-blue-400" },
            { screen: "Home / Monitoring Status", priority: "Core", color: "text-green-400" },
            { screen: "Live Vitals", priority: "Core", color: "text-green-400" },
            { screen: "Risk Level (Model Output)", priority: "Core", color: "text-green-400" },
            { screen: "Stroke Alert", priority: "Critical", color: "text-red-400" },
            { screen: "Emergency Actions", priority: "Critical", color: "text-red-400" },
          ].map((row) => (
            <div key={row.screen} className="flex justify-between items-center px-5 py-2.5" style={{ background: "rgba(0,0,0,0.3)" }}>
              <span className="text-gray-300 text-[12px]">{row.screen}</span>
              <span className={`text-[11px] ${row.color}`}>{row.priority}</span>
            </div>
          ))}
          <div className="flex justify-between items-center px-5 py-3" style={{ background: "rgba(255,255,255,0.04)" }}>
            <span className="text-gray-400 text-[12px]">+ iPhone companion (onboarding, contacts, history)</span>
            <span className="text-purple-400 text-[11px]">+3 screens</span>
          </div>
        </div>
      </div>

      <p className="text-gray-700 text-[11px] text-center max-w-xs pb-4">
        Tap any screen tab above to preview · Built per Apple watchOS HIG
      </p>
    </div>
  );
}
