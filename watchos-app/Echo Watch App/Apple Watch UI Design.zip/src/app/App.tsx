import { WatchSimulator } from "./components/WatchSimulator";

export default function App() {
  return (
    <div
      className="min-h-screen w-full flex flex-col items-center justify-start py-12 px-4"
      style={{ background: "#000000" }}
    >
      <WatchSimulator />
    </div>
  );
}
