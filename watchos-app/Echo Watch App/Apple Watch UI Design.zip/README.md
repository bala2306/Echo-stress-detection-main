
  # Apple Watch UI Design

  This is a code bundle for Apple Watch UI Design. The original project is available at https://www.figma.com/design/G9Y7U8sbRowmMx79Sedppw/Apple-Watch-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  